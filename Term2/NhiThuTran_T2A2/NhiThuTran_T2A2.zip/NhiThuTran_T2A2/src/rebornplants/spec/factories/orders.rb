FactoryBot.define do
  factory :order do
    listing { nil }
    buyer { nil }
    seller { nil }
  end
end
