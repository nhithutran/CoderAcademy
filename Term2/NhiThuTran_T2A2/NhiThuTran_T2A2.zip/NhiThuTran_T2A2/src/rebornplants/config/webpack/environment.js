const { environment } = require('@rails/webpacker')

module.exports = environment
