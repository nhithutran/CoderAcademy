class PageController < ApplicationController
  def home
  end

  def success
  end
end
